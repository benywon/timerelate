package TimeRelate;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by benywon on 2015/4/19.
 */
public class TimeWeight {
    public float Weight=0;
    public List<Integer> timelist=new ArrayList<>();
    public boolean HasDynasty;

    public TimeWeight(List<Integer> list)
    {
        this.timelist=list;
    }
    //开始设置我们的时间区间
    public void SetTimeInterval()
    {

    }
}
