package TimeRelate;

import BaiduRelate.Queryer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**这个的主要功能是给定一个item 我们得到它的一个时间区间
 * Created by benywon on 2015/4/16.
 */
public class GetItemTime {
    Date StartTime=new Date();
    Date EndTime=new Date();
//    List<String> regexlist=new ArrayList<>();
    public static  final String dateregex="公元前(\\d{1,4})年|(\\d{1,4})年[^前以之代]|年[\\(（](\\d{1,4})[\\)）]";
    String[] regexlist={"(\\d+)","公元前","公元","距今","世纪"};
    String[] ChineseNum={"零","一","二","三","四","五","六","七","八","九","十"};
    public boolean HasDynasty=false;
    /**
     * 检索功能的  将一个item从百度里面拿出来
     * @return
     */
    public String  getitemfrombaidu(String item)
    {
        String content = Queryer.GetStringFrom("lemmatitle", item);
        return content;
    }

    /**
     * 我们从一个文章里面抽取时间 这个可以是规则的方法（正则表达式==） 也可以是我们的其他方法 比如事件抽取中时间的抽取
     * @param str 输入的一篇文章
     */
    public static List<Integer> gettimeinterval(String str)
    {
        List<Integer> datelist=new ArrayList<>();
        /*
        首先简单匹配 就是纯阿拉伯字符串  但是前面有一些“公元”“年”==
         */
        Pattern p = Pattern.compile(dateregex);
        Matcher m = p.matcher(str);
        while (m.find()){
            //如果找到了  我们看是公元前还是公元后
            if(m.group(2)!=null)//直接是年份
            {
                String number=m.group(2);
                int date=Integer.parseInt(number);
                datelist.add(date);
            }
            else if(m.group(3)!=null)
            {
                String number=m.group(3);
                int date=Integer.parseInt(number);
                datelist.add(date);
            }
            else//公元前
            {
                String number=m.group(1);
                int date=-Integer.parseInt(number);
                datelist.add(date);
            }


        }
        return datelist;
    }

    /**+
     * 从一个字符串中获取百科页面时间list的函数
     * @param term
     * @return
     */
    public List<Integer> GetTermTimeList(String term)
    {
        GetItemTime getTime= new GetItemTime();
        List<Integer> datelist=new ArrayList<>();
        this.HasDynasty=false;
        //首先查找是不是包含一个朝代 要是的话 就直接将这个信息输出
        List<TimeInterval> dList=DealDynasty.dynastylist;
        for(TimeInterval timeInterval:dList)
        {
            String dy=timeInterval.Dynasty;
            if(term.equals(dy)||(term+"朝").equals(dy))
            {
                this.HasDynasty=true;
                for(int i=timeInterval.StartTime;i<timeInterval.EndTime;i++)
                {
                    datelist.add(i);
                }
                break;
            }
        }
        if(!this.HasDynasty) {
            String home = getTime.getitemfrombaidu(term);
            datelist = getTime.gettimeinterval(home);
        }
        return datelist;
    }
}
