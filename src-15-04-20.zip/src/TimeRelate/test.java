package TimeRelate;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by benywon on 2015/4/20.
 */
public class test {
    public static  final String dateregex="公元前(\\d{1,4})年|(\\d{1,4})年[^前|^后]";

    public static void main(String[] args) {
        Pattern p = Pattern.compile(dateregex);
        Matcher m = p.matcher("和达300年的武阳曹氏宗谱记载是一致的");
        if(m.find())
        {
            String out=m.group(2);
            System.out.println(out);
        }
    }
}
