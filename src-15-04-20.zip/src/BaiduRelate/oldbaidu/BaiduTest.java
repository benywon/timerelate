package BaiduRelate.oldbaidu;

import java.io.IOException;

/**
 * Created by benywon on 2015/1/28.
 */
public class BaiduTest {
    public static void main(String[] args) throws IOException {
        indexbaidu indexs=new indexbaidu();
        indexs.indexbaidufile("default","L:\\program\\cip\\SAT-HISTORY\\baiduindex");

    }
}
